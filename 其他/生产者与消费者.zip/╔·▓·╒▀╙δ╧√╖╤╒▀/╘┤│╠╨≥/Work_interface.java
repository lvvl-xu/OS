package new_last;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

//import ceshi2.ProducerAndConsumer;

public class Work_interface extends JFrame implements ActionListener {

	private static int m = 50;// �ٶȿ�����

	private static int i = 1;// ��ͣ������

	private static int counter = 0;// ����صĲ�Ʒ����

	public static void i() {
		Work_interface.i = 0;
	}

	public static int getM() {
		return m;
	}

	public static void increase() {
		Work_interface.m = Work_interface.m + 1;
	}

	public static void decrease() {
		if (Work_interface.m >= 1)
			Work_interface.m = Work_interface.m - 1;
	}

	JLabel lbl1 = new JLabel("����������ʾ");

	JTextArea txt = new JTextArea(200, 300);

	JScrollPane jsp = new JScrollPane(txt);// ���ӹ�����

	JButton btn1 = new JButton("����");

	JButton btn2 = new JButton("�˳�");

	JButton btn3 = new JButton("��������");

	JButton btn4 = new JButton("���Ѽ���");

	JButton btn5 = new JButton("��ͣ");

	JLabel lbl2 = new JLabel("   ������ڵĲ�Ʒ����");

	JTextField txt_1 = new JTextField(5);

	class Producer implements Runnable {     //�������߳���
		ProducerAndConsumer queue;

		public Producer(ProducerAndConsumer s) {
			queue = s;
		}

		public void run() {
			for (;;) {
				char c = (char) (Math.random() * 26 + 'A');//����Ĳ���һ����ĸ
				queue.inqueue(c);
				try {
					Thread.sleep(Work_interface.getM());
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
		}
	}

	class Consumer implements Runnable {   //�������߳���
		ProducerAndConsumer queue;

		public Consumer(ProducerAndConsumer s) {
			queue = s;
		}

		public void run() {
			for (;;) {
				queue.outqueue();
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
		}
	}

	class ProducerAndConsumer {     //��Դ������

		private int head = 0;// ��ͷ

		private int tail = 1;// ��β

		public final int Num = 20;// ��������С

		private int mutex = 1;// �����ź���

		// public int kongzhi = 1;// �����ź���

		public char data[] = new char[Num];

		public synchronized void inqueue(char c) {// ��ֹ����߳�ͬʱ������������synchronized����,�߳�ͬ��
			if (i == 0) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
			if (mutex == 0) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
			mutex--;
			while ((tail) % Num == head) {
				txt.append("�������������ȴ�." + "\n");
				txt_1.setText(counter + "");
				// txt_1.setText(counter+"");
				try {
					mutex++;
					this.wait();
				} catch (InterruptedException e) {
					System.out.println(e);
				}

			}
			this.notify();

			data[tail] = c;
			tail = (tail + 1) % Num;
			counter++;
			txt.append("����:" + c + "\n");
			txt_1.setText(counter + "");
			mutex++;
		}

		public synchronized char outqueue() {
			if (i == 0) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
			if (mutex == 0) {
				try {
					this.wait();
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
			mutex--;
			while ((head + 1) % Num == tail) {
				txt.append("���пգ����ѵȴ�." + "\n");
				txt_1.setText(counter + "");
				// txt_1.setText(counter+"");
				try {
					mutex++;
					this.wait();
				} catch (InterruptedException e) {
					System.out.println(e);
				}
			}
			this.notify();

			head = (head + 1) % Num;

			txt.append("���ѣ�" + data[head] + "\n");
			txt_1.setText(counter + "");
			counter--;
			mutex++;

			// txt.append("����ֵ��" + Work_interface.getM());
			return data[head];

		}
	}

	public Work_interface(String str) {
		this.setTitle(str);
		final JPanel jp = (JPanel) this.getContentPane();
		// jp.setLayout(new GridBagLayout());
		GridBagLayout grid = new GridBagLayout();// ʹ�����������
		GridBagConstraints c = new GridBagConstraints();

		setLayout(grid);
		c.fill = GridBagConstraints.NONE;//�����µ��������С

		// jp.add(jsp,grid,c);
		// jp.add(lbl1);
		// jp.add(btn1);
		// jp.add(btn2);
		// Label lbl1 = new Label("����������ʾ");
		//
		// TextArea txt = new TextArea(20, 30);
		//
		// JScrollPane jsp = new JScrollPane(txt);// ���ӹ�����
		//
		// Button btn1 = new Button("��ʾ");
		//
		// Button btn2 = new Button("�˳�");
		c.weightx = 1.8;//����ؼ��ֲ�
		c.weighty = 1;

		grid.setConstraints(btn1, c);
		c.weightx = 1;
		c.weighty = 1;

		grid.setConstraints(btn5, c);
		c.weightx = 1;
		c.weighty = 1;
		c.gridwidth = GridBagConstraints.REMAINDER;
		grid.setConstraints(btn2, c);
		c.weightx = 1;
		c.weighty = 1;
		// c.gridwidth =1;
		grid.setConstraints(btn3, c);
		c.weightx = 1;
		c.weighty = 2;
		// c.gridwidth = GridBagConstraints.REMAINDER;
		grid.setConstraints(btn4, c);
		c.weightx = 1;
		c.weighty = 1;

		grid.setConstraints(lbl1, c);
		c.weightx = 1;
		c.weighty = 13;
		// c.gridheight = 3;
		// c.gridwidth = 3;
		c.fill = GridBagConstraints.BOTH;

		grid.setConstraints(jsp, c);
		// c.fill = GridBagConstraints.NONE;
		c.gridwidth = 2;//�ؼ��ֲ�ռ�ĵ�Ԫ����
		c.weightx = 1;
		c.weighty = 1;
		grid.setConstraints(lbl2, c);
		c.gridwidth = 3;
		c.weightx = 2;
		c.weighty = 1;
		grid.setConstraints(txt_1, c);
		jp.add(btn1);
		jp.add(btn5);
		jp.add(btn2);
		jp.add(btn3);
		jp.add(btn4);
		jp.add(lbl1);
		jp.add(jsp);
		jp.add(lbl2);
		jp.add(txt_1);

		btn1.addActionListener(this);
		btn2.addActionListener(this);
		btn3.addActionListener(this);
		btn4.addActionListener(this);
		btn5.addActionListener(this);
		addWindowListener(new WindowAdapter() {// ����� X, �رմ���
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}

	public void actionPerformed(final ActionEvent ae) {
		if (ae.getSource() == btn1) {
			txt.setText(null);
			Work_interface.i = 1;
			ProducerAndConsumer queue = new ProducerAndConsumer();
			Runnable p = new Producer(queue);
			Runnable c = new Consumer(queue);
			Thread t1 = new Thread(p);
			Thread t2 = new Thread(c);
			Thread t3 = new Thread(p);
			Thread t4 = new Thread(c);
			t1.start();
			t2.start();
			t3.start();
			t4.start();
			counter=0;

		}
		if (ae.getSource() == btn2) {
			System.exit(0);
			// queue.kongzhi=0;
		}
		if (ae.getSource() == btn3) {
			Work_interface.decrease();
		}
		if (ae.getSource() == btn4) {
			Work_interface.increase();
		}
		if (ae.getSource() == btn5) {
			Work_interface.i();
		}
	}

}
