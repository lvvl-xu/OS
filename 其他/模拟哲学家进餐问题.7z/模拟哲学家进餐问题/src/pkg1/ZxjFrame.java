
package pkg1;
import java.awt.*;                   
import java.awt.event.*; 
import javax.swing.*; 



//////////////////////������ //////////////////////////////////////////////////////////////

class Kuaizi {                   
   boolean bState;               //���ӵ�״̬
   JLabel bLabel;                       //��ʾ��ѧ����ǰ���п��ӵ�JLabel
   ImageIcon emptyImage,kuaiziImage;                //����ʱΪemptyͼƬ������Ϊ����ͼƬ   
   
   public Kuaizi(JLabel bLabel, ImageIcon image) {     //���ӵĹ��캯�� 
       emptyImage=new ImageIcon("�յ�.jpg"); 
       this.bLabel=bLabel;   
       this.kuaiziImage=image; 
       bState=true;                    //һ��ʼ�������Ϊ����״̬
   } 
   
   public synchronized void gotKuaizi() {           
       while(!bState) {                  //����˿����ѱ��ã���ȴ�    
           try { 
               wait(); 
           }catch(Exception e) { 
        	   e.printStackTrace();
           } 
       } 
       bLabel.setIcon(emptyImage);         //��ÿ��ӣ����ѿ��������� ��ͼƬ��Ϊ��      
       bState=false;                      //�Ѵ˿��ӵ�״̬��Ϊ�ѱ�����        
   } 
   
   public synchronized void putdownKuaizi() {          //���¿��ӣ��ѿ���״̬��Ϊ����
       bState=true;                   
       bLabel.setIcon(kuaiziImage);                  
       notify();                             //���������ڵȴ����̣߳�����еȴ��˿��ӵ��̣߳�����Լ����ж�
   } 
} 
 
////////////////////////////��ѧ����//////////////////////////////////////////////////////////////////////

class Zexuejia extends Thread {       


	int thinkTime, eatTime; // ˼��ʱ�䣬�Է�ʱ��

	Kuaizi left, right; // ��ѧ�ҵ����ҿ���

	int num; // ��ѧ�ұ��

	JLabel zxjLable, leftLable, rightLable, zxjLeftLabel, zxjRightLabel;  
	ImageIcon leftImage, rightImage;     //�����������ӵ�ͼƬ

	Zexuejia(int num, JLabel zLabel, Kuaizi left, JLabel lLabel,
			Kuaizi right, JLabel rLabel, ImageIcon lImage, ImageIcon rImage, JLabel zLLabel, 
			JLabel zRLabel)              //��ѧ�ҵĹ��캯��
			{
		this.num = num;            
		this.zxjLable = zLabel;
		this.left = left;
		this.leftLable = lLabel;
		this.right = right;                 //�βε�ֵ������Ա����
		this.rightLable = rLabel;
		this.leftImage = lImage;
		this.rightImage = rImage;
		this.zxjRightLabel = zRLabel;
		this.zxjLeftLabel = zLLabel;
	
	         } 
   public void run() {
		ImageIcon thinkImage = new ImageIcon("thinking.gif");
		ImageIcon huangryImage = new ImageIcon("huangry.gif");
		ImageIcon eatImage = new ImageIcon("eating.gif");
		ImageIcon empty = new ImageIcon("empty.jpg");
		while (true) {
			
			zxjLable.setIcon(thinkImage);
	
			do {
				thinkTime = (int) (Math.random() * 10000); // ��������˼��ʱ��
			} while (thinkTime < 2500);
			try {
				sleep(thinkTime); // ���߳�˯�ߵķ�ʽ����ѧ��˼��һЩʱ��
			} catch (Exception e) {
			}
			zxjLable.setIcon(huangryImage);
			synchronized (left){
			left.gotKuaizi(); // �����ߵĿ���
			zxjLeftLabel.setIcon(leftImage);
			}
			synchronized (right) {
			right.gotKuaizi(); // ����ұߵĿ���
			zxjRightLabel.setIcon(rightImage);
			}
			zxjLable.setIcon(eatImage);
			do {
				eatTime= (int) (Math.random() * 10000); // �������ĳԷ�ʱ��
			} while (eatTime < 2500);
			try {
				sleep(eatTime); // ���߳�˯�ߵķ�ʽ����ѧ�ҳԷ�һЩʱ��
			} catch (Exception e) {
			}
			synchronized (left) {
				left.putdownKuaizi(); // ������ߵĿ���
				zxjLeftLabel.setIcon(empty);
			}
			synchronized (right) {
				right.putdownKuaizi(); // �����ұߵĿ���
				zxjRightLabel.setIcon(empty);
			}
		}
	} 
} 
//////////////////////////////////////////////////����///////////////////////////////////////////////
public class ZxjFrame extends JFrame implements ActionListener {    
   JButton start_Button,end_Button;      
   JLabel kuaiziLabel[];           //���п��ӱ�ǩ����
   JLabel h[];                   //��ѧ�ҳԷ�ʱ���ӱ�ǩ����
   JLabel zxjLable[];            //��ѧ�ұ�ǩ����
   Kuaizi kuaizi[];           // ���Ӷ�������
   Zexuejia zxj[];       // ��ѧ�Ҷ�������
   ImageIcon kuaiziImage[],empty,thinkImage,huangryImage,eatImage; 
   ZxjFrame() 
   {           // ���캯��
       super("              ----�����ѧ�ҽ�������ģ��----           ");           
       this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE); 
       Container container=this.getContentPane(); 
      
       container.setBackground(Color.white);
           
       thinkImage=new ImageIcon("thinking.gif"); 
       huangryImage=new ImageIcon("huangry.gif"); 
       eatImage=new ImageIcon("eating.gif"); 
       empty=new ImageIcon("�յ�.gif"); 
       JPanel panel=new JPanel(); 
       panel.setLayout(new FlowLayout()); 

       
       zxjLable=new JLabel[6]; 
       for(int i=1;i<=5;i++) { 
           zxjLable[i]=new JLabel(); 
           zxjLable[i].setIcon(thinkImage);   //һ��ʼ��Ϊ˼�� 
       } 
               
       kuaiziImage=new ImageIcon[6]; 
       kuaiziImage[1]=new ImageIcon("kuaizi.gif"); 
       kuaiziImage[2]=new ImageIcon("kuaizi.gif"); 
       kuaiziImage[3]=new ImageIcon("kuaizi.gif"); 
       kuaiziImage[4]=new ImageIcon("kuaizi.gif"); 
       kuaiziImage[5]=new ImageIcon("kuaizi.gif"); 
       
      kuaiziLabel=new JLabel[6]; 
       kuaiziLabel[1]=new JLabel(); kuaiziLabel[1].setIcon(kuaiziImage[1]); 
       kuaiziLabel[2]=new JLabel(); kuaiziLabel[2].setIcon(kuaiziImage[2]); 
       kuaiziLabel[3]=new JLabel(); kuaiziLabel[3].setIcon(kuaiziImage[3]); 
       kuaiziLabel[4]=new JLabel(); kuaiziLabel[4].setIcon(kuaiziImage[4]); 
      kuaiziLabel[5]=new JLabel(); kuaiziLabel[5].setIcon(kuaiziImage[5]); 
       
       kuaizi=new Kuaizi[6];       
       for(int i=1;i<=5;i++) kuaizi[i]=new Kuaizi(kuaiziLabel[i],kuaiziImage[i]);   //���Ӷ���ĳ�ʼ�� 
       
       h=new JLabel[13]; 
       for(int i=1;i<=12;i++) { 
           h[i]=new JLabel(); 
           h[i].setIcon(empty); 
       } 
       
       zxj=new Zexuejia[6];       
       
       panel=new JPanel();          
       panel.setLayout(new GridBagLayout()); //���ӵ����񲼾�
       GridBagConstraints gbc=new GridBagConstraints(); //ȷ�������С��λ�õĲ�������GridBagConstraints��Ķ����������ʵ�ֵġ�
      
       gbc.weightx=1;   gbc.weighty=1;    //��������������ָ��ÿ���������������п���ÿ���������������п���
       gbc.gridwidth=1;   gbc.gridheight=1; //��������������ָ������ĳ��Ⱥ͸߶ȣ����Ƿֱ������������������Ϊ��λ��
       gbc.gridy=0; 
       gbc.gridx=4;   panel.add(h[2],gbc); //��������������ָ�������λ�ã����������������λ�õ����Ͻ����꣬������ĵ�λ��������������
       gbc.gridx=6;   panel.add(h[1],gbc); 
       gbc.gridy=1;   
       gbc.gridx=5;   panel.add(zxjLable[1],gbc); 
       gbc.gridy=2; 
       gbc.gridx=0;   panel.add(h[3],gbc); 
       gbc.gridx=3;   panel.add(kuaiziLabel[1],gbc); 
       gbc.gridx=7;   panel.add(kuaiziLabel[5],gbc); 
       gbc.gridx=10;   panel.add(h[10],gbc); 
       gbc.gridy=3; 
       gbc.gridx=1;   panel.add(zxjLable[2],gbc); 
       gbc.gridx=9;   panel.add(zxjLable[5],gbc); 
       gbc.gridy=4; 
       gbc.gridx=0;   panel.add(h[4],gbc); 
       gbc.gridx=10;   panel.add(h[9],gbc); 
       gbc.gridy=5; 
       gbc.gridx=2;   panel.add(kuaiziLabel[2],gbc); 
       gbc.gridx=8;   panel.add(kuaiziLabel[4],gbc); 
       gbc.gridy=7;  
       gbc.gridx=3;   panel.add(zxjLable[3],gbc); 
       gbc.gridx=5;   panel.add(kuaiziLabel[3],gbc);
       gbc.gridx=7;   panel.add(zxjLable[4],gbc); 
       gbc.gridy=8; 
       gbc.gridx=2;   panel.add(h[5],gbc); 
       gbc.gridx=4;   panel.add(h[6],gbc); 
       gbc.gridx=6;   panel.add(h[7],gbc); 
       gbc.gridx=8;   panel.add(h[8],gbc); 
       container.add(panel,BorderLayout.CENTER); 
       
       zxj[1]=new Zexuejia(1, zxjLable[1], kuaizi[5], kuaiziLabel[5],            
              kuaizi[1], kuaiziLabel[1], kuaiziImage[5], kuaiziImage[1], h[1], h[2]); 
       zxj[2]=new Zexuejia(2, zxjLable[2], kuaizi[2], kuaiziLabel[2], 
               kuaizi[1], kuaiziLabel[1], kuaiziImage[2], kuaiziImage[1], h[4], h[3]); 
       zxj[3]=new Zexuejia(3, zxjLable[3], kuaizi[2], kuaiziLabel[2], 
              kuaizi[3], kuaiziLabel[3], kuaiziImage[2], kuaiziImage[3], h[5], h[6]); 
       zxj[4]=new Zexuejia(4, zxjLable[4], kuaizi[4], kuaiziLabel[4], 
               kuaizi[3], kuaiziLabel[3], kuaiziImage[4], kuaiziImage[3], h[8], h[7]); 
       zxj[5]=new Zexuejia(5, zxjLable[5], kuaizi[4], kuaiziLabel[4], 
             kuaizi[5], kuaiziLabel[5], kuaiziImage[4], kuaiziImage[5], h[9], h[10]); 
       
       start_Button=new JButton("��ʼ��ʾ");               
       start_Button.setEnabled(true); 
       start_Button.addActionListener(this); 
       end_Button=new JButton("�رճ���"); 
       end_Button.addActionListener(this); 
       panel=new JPanel(new FlowLayout()); //�����ֹ�����
       panel.add(start_Button); 
       panel.add(end_Button); 
      container.add(panel,BorderLayout.NORTH); //�߽粼�ֹ������������������������
   } 
   
   public void actionPerformed(ActionEvent e) { // ͼ�ΰ�ť�ļ���������������ť
		if (e.getSource() == start_Button) {
			for (int i = 1; i <= 5; i++)
				zxj[i].start(); // �����߳�
			start_Button.setEnabled(false);
		} else if (e.getSource() == end_Button) {
			System.exit(0);
		}
	} 

   public static void main(String[] args) {
	   ZxjFrame f = new ZxjFrame();
	   
		f.setSize(720, 480);
		f.setVisible(true);
	} 
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                