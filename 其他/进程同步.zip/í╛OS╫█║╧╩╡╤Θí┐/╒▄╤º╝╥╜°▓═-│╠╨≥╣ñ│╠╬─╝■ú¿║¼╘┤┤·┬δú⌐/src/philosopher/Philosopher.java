
package philosopher;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.Timer;

public class Philosopher {
    /*
     * -----哲学家状态----- 0：思考 1：饥饿 2：进餐
     */
    static int state[] = new int[5];
    
    /*
     * ------筷子状态-------- 0：可用 1：不可用
     */
    static int chopstick[] = new int[5];    
    
//    static boolean stopOrStart = false;
    
    static P p1 = new P(0);
    static P p2 = new P(1);
    static P p3 = new P(2);
    static P p4 = new P(3);
    static P p5 = new P(4);
    static Show show = new Show();
    static MainFrame f = new MainFrame();
//    static Timer time = new Timer(1,new ActionListener(){
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            show.run();
//        }       
//    });
    public static void main(String[] args) throws InterruptedException {
        f.setSize(700, 550);
        f.setVisible(true);
        //--------初始化--------
        for (int element : state) {
            element = 0;
        }
        for (int element : chopstick) {
            element = 0;
        }
        
        show.start();
    }
    
    //------------------线程类-------------------
    static class P extends Thread{
        int num;
        
        public P(int num) {
            this.num=num;
        }       
        @Override
        public void run() {
            
            int sign;
            while(true){ 
                
                sign = (int) (Math.random()*5);
                
                try {
                        this.sleep(500);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
                    }
                
                if(sign==this.num && state[this.num]==0){ 
                    //随机命中该线程且该哲学家正处思考中，则转换为饥饿状态                   
                    state[this.num] = 1;                    
                }
                
                try {
                    this.sleep(400);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                if(state[this.num]==1){
                    try {                        
                        testEating(this.num);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
                try {   
                        this.sleep(2000);//让其睡眠2秒再释放
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
                    }
                
                if(state[num]==2){
                    release(num);                   
                }
                
                try {
                        //该哲学家处进餐状态
                        this.sleep(1000);//让其睡眠2秒再释放
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
                    }
            }                             
        }
        
        boolean testEating(int num) throws InterruptedException {
            //----------检测是否能进餐----------
            if (chopstick[num] == 0 && chopstick[(num + 4) % 5] == 0) {
                //左右筷子都可用
                state[num] = 2;//哲学家状态设置为2（进餐）                
                chopstick[num] = chopstick[(num + 4) % 5] = 1;//左右筷子的状态都设置为1（不可用）
                return true;
            } else {
                //左右筷子不可用
                return false;
            }
        }
        
        void release(int num){
            //---------就餐结束的哲学家释放筷子-------
            chopstick[num] = chopstick[(num + 4) % 5] = 0;//左右筷子的状态都设置为0（可用）
            state[num]=0;
        }
        
    }
    //--------------------------------------------
    
    static class Show extends Thread{
        //另外一进程 用以控制其他5个进程
        int j=0;
        @Override
        public void run() {
            
            p1.start();
            p2.start();
            p3.start();
            p4.start();
            p5.start();
            while(true){
                for(int i=0;i<5;i++)
                    System.out.print(state[i]+" ");
                System.out.println("");
                j++;
                try {
                    this.sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Philosopher.class.getName()).log(Level.SEVERE, null, ex);
                }
                System.out.println("");  
                PanelShow();
            }
        }
        boolean PanelShow(){
            if(state[0]==0){
                    f.tablePanel.jPanel1.setBackground(Color.YELLOW);
                    f.tablePanel.jLabel6.setIcon(new ImageIcon(getClass().getResource("/philosopher/thinking.gif")));
            }
                else if(state[0]==1){
                    f.tablePanel.jPanel1.setBackground(Color.RED);
                    f.tablePanel.jLabel6.setIcon(new ImageIcon(getClass().getResource("/philosopher/hungry1.gif")));
                }
                else{
                    f.tablePanel.jPanel1.setBackground(Color.GREEN);
                    f.tablePanel.jLabel6.setIcon(new ImageIcon(getClass().getResource("/philosopher/eating1.gif")));
                }
            
            if(state[1]==0)
            {
                    f.tablePanel.jPanel2.setBackground(Color.YELLOW);
                    f.tablePanel.jLabel8.setIcon(new ImageIcon(getClass().getResource("/philosopher/thinking.gif")));
            }
                else if(state[1]==1){
                    f.tablePanel.jPanel2.setBackground(Color.RED);
                    f.tablePanel.jLabel8.setIcon(new ImageIcon(getClass().getResource("/philosopher/hungry1.gif")));
                }
                else{
                    f.tablePanel.jPanel2.setBackground(Color.GREEN);
                    f.tablePanel.jLabel8.setIcon(new ImageIcon(getClass().getResource("/philosopher/eating1.gif")));
                }
            
            if(state[2]==0){
                    f.tablePanel.jPanel7.setBackground(Color.YELLOW);
                    f.tablePanel.jLabel7.setIcon(new ImageIcon(getClass().getResource("/philosopher/thinking.gif")));
            }
                else if(state[2]==1){
                    f.tablePanel.jPanel7.setBackground(Color.RED);
                    f.tablePanel.jLabel7.setIcon(new ImageIcon(getClass().getResource("/philosopher/hungry1.gif")));
                }
                else{
                    f.tablePanel.jPanel7.setBackground(Color.GREEN);
                    f.tablePanel.jLabel7.setIcon(new ImageIcon(getClass().getResource("/philosopher/eating1.gif")));
                }
            
            if(state[3]==0){
                    f.tablePanel.jPanel6.setBackground(Color.YELLOW);
                    f.tablePanel.jLabel10.setIcon(new ImageIcon(getClass().getResource("/philosopher/thinking.gif")));
            }
                else if(state[3]==1){
                    f.tablePanel.jPanel6.setBackground(Color.RED);
                    f.tablePanel.jLabel10.setIcon(new ImageIcon(getClass().getResource("/philosopher/hungry1.gif")));
                }
                else{
                    f.tablePanel.jPanel6.setBackground(Color.GREEN);
                    f.tablePanel.jLabel10.setIcon(new ImageIcon(getClass().getResource("/philosopher/eating1.gif")));
                }
            
            if(state[4]==0){
                    f.tablePanel.jPanel3.setBackground(Color.YELLOW);
                    f.tablePanel.jLabel9.setIcon(new ImageIcon(getClass().getResource("/philosopher/thinking.gif")));
            }       
                else if(state[4]==1){
                    f.tablePanel.jPanel3.setBackground(Color.RED);
                    f.tablePanel.jLabel9.setIcon(new ImageIcon(getClass().getResource("/philosopher/hungry1.gif")));
                }
                else{
                    f.tablePanel.jPanel3.setBackground(Color.GREEN);
                    f.tablePanel.jLabel9.setIcon(new ImageIcon(getClass().getResource("/philosopher/eating1.gif")));
                }
            return true;
        }
    }
}
