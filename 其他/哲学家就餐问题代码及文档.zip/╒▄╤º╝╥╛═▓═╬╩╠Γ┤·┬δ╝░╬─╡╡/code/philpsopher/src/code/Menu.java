/***
 * �˵���
 */
package code;
import javax.swing.*; 

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
public class Menu extends JFrame{
	JMenuBar    bar;
	JMenu          fileMenu;
	JMenu  openMItem;
	JMenuItem exitMItem;
	JRadioButtonMenuItem choice[];
    JPanel panel=new JPanel();
    JPanel pan=new JPanel();
    JPanel pan1=new JPanel();
    ImageIcon icon;
   // JLabel title,jlable1,jlable2,jlabel3;
     ButtonGroup ChoiceGroup;
     //int count;
     interface1 m0=new interface1();//�������4��ѧ��ͬʱ����
     interface2 m1=new interface2();//����ż��
     interface3 m2=new interface3();//AND�ź�������
     interface4 m4=new interface4();//��¼���ͺ���
     Eat  eat=new Eat("�ֶ�--��������");
     Eat2  eat2=new Eat2("�ֶ�--��ֻ����ͬʱȡ");
	Menu(String s){
	    super(s);
	    
	    icon = new ImageIcon("13.jpg");
	    JPanel panel1=new JPanel()
	    {
	        protected void paintComponent(Graphics g)
	        {
	            g.drawImage(icon.getImage(), 0, 0, null);
	            super.paintComponent(g);
	        }
	    };
	    panel1.setOpaque( false );
        panel1.setPreferredSize( new Dimension(700, 600) );
        
	    JLabel jlabel1=new JLabel("        ��ѧ�ҽ���ģ��");
		jlabel1.setFont(new Font("����",Font.PLAIN,40));
		jlabel1.setForeground(Color.red); 
		jlabel1.setVerticalAlignment(jlabel1.CENTER);
		jlabel1.setSize(900,300);
	    JLabel jlabel2=new JLabel("              				���繤��81��");
	    jlabel2.setFont(new Font("����",Font.PLAIN,40));
		jlabel2.setForeground(Color.red); 
		jlabel2.setVerticalAlignment(jlabel1.CENTER);
		jlabel2.setSize(900,300);
	    JLabel jlabel3=new JLabel("                     				   ����    1938102");
	    jlabel3.setFont(new Font("����",Font.PLAIN,30));
		jlabel3.setForeground(Color.red); 
		jlabel3.setVerticalAlignment(jlabel1.CENTER);
		jlabel3.setSize(900,300);
	    JLabel jlabel4=new JLabel("                        				��ΰ��   1938114");
	    jlabel4.setFont(new Font("����",Font.PLAIN,30));
		jlabel4.setForeground(Color.red); 
		jlabel4.setVerticalAlignment(jlabel1.CENTER);
		//jlabel4.setSize(900,300);
		//panel.setSize(900,600);
	    panel.setLayout(new BorderLayout());
	    panel.add(jlabel1,"Center");
	    //panel.add(pan,"South");
	    pan.setLayout(new BorderLayout());
	    pan.add(jlabel2,"Center");
	    pan1.setLayout(new BorderLayout());
	    pan1.add(jlabel3,"North");
	    pan1.add(jlabel4,"South");
	    pan.add(pan1,"South");
	   
	    bar= new   JMenuBar();
	    fileMenu = new JMenu("�ļ�");
	    fileMenu.setFont(new Font("����",Font.PLAIN,20));
	    fileMenu .setForeground(Color.blue); 
	    openMItem  =new JMenu("��");
	    openMItem.setFont(new Font("����",Font.PLAIN,20));
	    openMItem .setForeground(Color.blue); 
		
	    exitMItem =new JMenuItem("�˳�");
	    exitMItem.setFont(new Font("����",Font.PLAIN,20));
	    exitMItem .setForeground(Color.blue); 
	    fileMenu.add( openMItem );
	    fileMenu.add( exitMItem );
	    bar.add( fileMenu );
	    setJMenuBar( bar );	  
	    String names[]={"��¼���ź���","AND�ź�������","����ż��","�������4��ѧ��ͬʱ����","�ֶ�--��������","�ֶ�--��ֻ����ͬʱȡ"};
	  //  String names[]={"1","2","3"};
	    choice=new JRadioButtonMenuItem[names.length+1];
	    ChoiceGroup=new ButtonGroup();
	   
	    choice[0]=new JRadioButtonMenuItem(names[0]);
    	openMItem.add(choice[0]);
    	ChoiceGroup.add(choice[0]);
    	choice[1]=new JRadioButtonMenuItem(names[1]);
    	openMItem.add(choice[1]);
    	ChoiceGroup.add(choice[1]);
    	choice[2]=new JRadioButtonMenuItem(names[2]);
    	openMItem.add(choice[2]);
    	ChoiceGroup.add(choice[2]);
    	 choice[3]=new JRadioButtonMenuItem(names[3]);
     	openMItem.add(choice[3]);
     	ChoiceGroup.add(choice[3]);
     	choice[4]=new JRadioButtonMenuItem(names[4]);
     	openMItem.add(choice[4]); 
     	ChoiceGroup.add(choice[4]);
     	choice[5]=new JRadioButtonMenuItem(names[5]);
    	openMItem.add(choice[5]);
    	ChoiceGroup.add(choice[5]);
	    choice[0].addActionListener(new ActionListener()//���ü�����
	    {
	    	public void actionPerformed(ActionEvent e){
	    		m4.setSize(900,700);
	    		m4.setVisible(true);
	    	}
	    });
	   choice[1].addActionListener(new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e){
	    		m2.setSize(900,700);
	    		m2.setVisible(true);
	    	}
	    });
	   choice[2].addActionListener(new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e){
	    		m1.setSize(900,700);
	    		m1.setVisible(true);
	    	}
	    });
	   choice[3].addActionListener(new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e){
	    		m0.setSize(900,700);
	    		m0.setVisible(true);
	    	}
	    });
	   choice[4].addActionListener(new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e){
	    		eat.setSize(900,700);
	    		eat.setVisible(true);
	    	}
	    });
	   choice[5].addActionListener(new ActionListener()
	    {
	    	public void actionPerformed(ActionEvent e){
	    		eat2.setSize(900,700);//���ý����С
	    		eat2.setVisible(true);
	    	}
	    });
	    exitMItem.addActionListener(new ActionListener(){
	    	public void actionPerformed(ActionEvent e){
	    		
	    		System.exit(0);
	    	}
	    });
	    panel.setSize(600,700);
	    //panel1.setLayout(new BorderLayout());
	    panel1.add(panel,"Center");
	    Container con=getContentPane();
	    con.setLayout(new BorderLayout());
	    con.add(panel1,"Center");
	    con.add(pan,"South");
}
	    public static void main(String args[]){
	      Menu  s=new Menu("��ѧ�ҽ���ģ��");
	     s.setLocationRelativeTo( null );
	      s.setSize(900,700); 
	      s.setVisible(true);  
	    }
}
