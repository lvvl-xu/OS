package war;

class DataFile {

    //表示正在进行读取操作的人数
    private int readerCount;
    //doreading 表示读信号量 当 doreading = true 时 表示有线程在读无法进行写操作
    private boolean doreading;
    //dowriting 表示写信号量 当 dowriting = true 时 表示有线程在写无法进行读操作      如何解决一个线程在写让另外其他的不能写？
    private boolean dowriting;
    private int rrr;

    public DataFile() {
        readerCount = 0;
        doreading = false;
        dowriting = false;
        rrr = 0;
    }

    public static void naps() {
        try {
            Thread.sleep((int) (4000 * Math.random()));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public synchronized int startRead() //开始读操作
    {
        rrr++;
        while (dowriting == true) // 当有写线程在完成写操作时  读线程等待写线程唤醒
        {
            try {
                System.out.println(Thread.currentThread().getName() + "临界资源被占用");
                //等待写者发出notify
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println(Thread.currentThread().getName() + "开始进行读操作");
        readerCount++;
        if (readerCount >= 1) {
            doreading = true;
        }
        return readerCount;
    }

    public synchronized int endRead() //结束读操作
    {
        --readerCount;
        --rrr;
        if (readerCount == 0) {
            doreading = false;
        }
        notifyAll();
        System.out.println(Thread.currentThread().getName() + "读操作结束");
        if(readerCount==0)
        {
         System.out.println("此时无读者在读，临界资源释放");
        }

        return readerCount;
    }

    public synchronized void startWrite() //开始写操作
    {
        while (doreading == true || dowriting == true) {
            try {
                System.out.println(Thread.currentThread().getName() + "临界资源被占用");
                //等待读者或者写者发出信息
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        while(true)    
        {
             if (rrr == 0) {
                System.out.println(Thread.currentThread().getName() + "开始进行写操作");
                dowriting = true;
                break;
            } else {
                try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            }
        }
    }

    public synchronized void endWrite() //结束写操作
    {
        dowriting = false;
        notifyAll();
        System.out.println(Thread.currentThread().getName() + "写操作结束，释放临界资源");
    }
}

class Reader implements Runnable {

    private int readerNum;

    private DataFile df;

    Reader(int readerNum, DataFile df) {
        this.readerNum = readerNum;
        this.df = df;
    }

    public void run() {
        df.naps();
        df.startRead();
        df.naps();
        df.endRead();
    }
}

class Writer implements Runnable {

    private int writerNum;

    private DataFile df;

    Writer(int writerNum, DataFile df) {
        this.writerNum = writerNum;
        this.df = df;
    }

    public void run() {
        df.naps();
        df.startWrite();
        df.naps();
        df.endWrite();
    }
}

class WAR {

    public static void main(String[] args) {
        DataFile df = new DataFile();

        Reader r1 = new Reader(1, df);
        Reader r2 = new Reader(2, df);
        Reader r3 = new Reader(3, df);
        Reader r4 = new Reader(4, df);

        Writer w1 = new Writer(1, df);
        Writer w2 = new Writer(2, df);
        Writer w3 = new Writer(3, df);

        new Thread(r1, "读者线程r1   ").start();
        new Thread(r2, "读者线程r2   ").start();
        new Thread(r3, "读者线程r3   ").start();
        new Thread(r4, "读者线程r4   ").start();
        new Thread(w1, "写者线程w1   ").start();
        new Thread(w2, "写者线程w2   ").start();
        new Thread(w3, "写者线程w3   ").start();
    }
}
