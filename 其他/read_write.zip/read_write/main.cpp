#include<windows.h>
#include<fstream>
#include<cstdlib>
#include<iostream>
using namespace std;

/*===============   class   signal   ===============*/
class signal //�ź�������.
{
private:
    int value;
    int queue;     //��int������ģ��ȴ�����.
public:
    signal();
    signal(int n);
    int P(); //����ٽ���Դ
    int V(); //�ͷ��ٽ���Դ
    int Get_Value();
    int Get_Queue();
};



const int MaxThread=20;

struct ThreadInfo
{
    int num;
    char type;
    double start;
    double time;
} thread_info[MaxThread];

void Creat_Writer();    //����һ��д��
void Del_Writer();     //ɾ��һ��д��
void Creat_Reader();    //����һ������
void Reader_goon();     //���߽������к���
void R_Wakeup();     //���ѵȴ�����
void Del_Reader();     //ɾ��һ������
void Show();     //��ʾ����״̬


HANDLE hX;
HANDLE hWsem;
HANDLE thread[MaxThread];
int readcount;
double totaltime;

void WRITEUNIT(int iProcess)
{
    printf("Thread %d begins to write.\n",iProcess);
    Sleep((DWORD)(thread_info[iProcess-1].time*1000));
    printf("End of thread %d  for writing.\n",iProcess);

}

void READUNIT(int iProcess)
{
    printf("Thread %d begins to read.\n",iProcess);
    Sleep((DWORD)(thread_info[iProcess-1].time*1000));
    printf("End of thread %d  for reading.\n",iProcess);
}

DWORD   WINAPI   reader(LPVOID   lpVoid)
{
    int iProcess   =   *(int*)lpVoid;
    Sleep((DWORD)(thread_info[iProcess-1].start*1000));
    DWORD wait_for=WaitForSingleObject(hX,INFINITE);
    printf("Thread %d requres reading.\n",iProcess);
    readcount++;
    if(readcount==1)WaitForSingleObject(hWsem,INFINITE);
    ReleaseMutex(hX);
    READUNIT(iProcess);
    wait_for=WaitForSingleObject(hX,INFINITE);
    readcount--;
    if(readcount==0)
        ReleaseSemaphore(hWsem,1,0);
    ReleaseMutex(hX);
    return iProcess;
}

DWORD   WINAPI   writer(LPVOID   lpVoid)
{
    int iProcess   =   *(int*)lpVoid;
    Sleep((DWORD)(thread_info[iProcess-1].start*1000));
    printf("Thread %d requres writing.\n",iProcess);
    DWORD wait_for=WaitForSingleObject(hWsem,INFINITE);
    WRITEUNIT(iProcess);
    ReleaseSemaphore(hWsem,1,0);
    return iProcess;
}

int main()
{
    int threadNum;
    int threadcount;
    ifstream file;

    hX=CreateMutex(NULL, FALSE, NULL);
    hWsem=CreateSemaphore(NULL,1,1,NULL);

    //???????????????????
    readcount=0;
    threadcount=0;
    totaltime=0;
    file.open("thread.dat",ios::in);
    if(file==0)
    {
        printf("File Open Error.\n");
        return 0;
    }
    while(file>>threadNum)
    {
        thread_info[threadNum-1].num=threadNum;
        file>>thread_info[threadNum-1].type;
        file>>thread_info[threadNum-1].start;
        file>>thread_info[threadNum-1].time;
        totaltime+=thread_info[threadNum-1].time;
        switch(thread_info[threadNum-1].type)
        {
        case 'W':
            printf("Creating Thread %d  for writing.\n",thread_info[threadNum-1].num);
            thread[threadNum-1]   =   CreateThread(NULL,   0,writer,   &thread_info[threadNum-1].num,0,0);
            break;
        case 'R':
            printf("Creating Thread %d  for reading.\n",thread_info[threadNum-1].num);
            thread[threadNum-1]   =   CreateThread(NULL,   0,reader,   &thread_info[threadNum-1].num,0,0);
            break;
        }
        threadcount++;
    }
    file.close();

    Sleep((DWORD)(totaltime*1000));
    return 1;
}
