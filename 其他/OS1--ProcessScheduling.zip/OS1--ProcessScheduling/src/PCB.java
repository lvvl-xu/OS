
public class PCB {
//	public PCB(int aPid,int aStatus,int aPriority,int aLife) {
//		pid = aPid;
//		status = aStatus;
//		priority = aPriority;
//		life = aLife;
//	}
	
	private int pid; //进程标识符
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public int getLife() {
		return life;
	}
	public void setLife(int life) {
		this.life = life;
	}

	private int status; //进程的状态标识，取值为“就绪 ready--0 ”或“运行 run--1 ”
	private int priority; //进程优先级
    //PCB *next;//进程队列指针
	private int life; //进程生命周期
}
