import java.awt.Container;
import javax.swing.JFrame;


public class ProcessScheduling {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PSFrame psFrame = new PSFrame();
		psFrame.setVisible(true);
	}

}

class PSFrame extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PSFrame() {
		setBounds(50, 50, 1200, 600);
		setTitle("实验一：进程调度");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setLayout(null);
		
		Container container = getContentPane();
		
		processPanel = new ProcessPanel();
		processPanel.setBounds(10, 90, 1170, 460);
		container.add(processPanel);
		
		ButtonPanel buttonPanel = new ButtonPanel(processPanel);
		container.add(buttonPanel);
		
	}
	public ProcessPanel processPanel;
}
