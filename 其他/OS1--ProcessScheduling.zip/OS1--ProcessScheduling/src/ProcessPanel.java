import java.awt.Color;
import java.awt.Font;
import java.util.LinkedList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ProcessPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProcessPanel() {
		setBackground(Color.green);
		setLayout(null);

		JLabel label = new JLabel("当前调度进程为：");
		label.setFont(new Font("楷体", Font.BOLD, 25));
		label.setForeground(Color.red);
		label.setBounds(230, 10, 250, 40);
		add(label);

		currentLabel = new JLabel("Scheduling process has not yet started !");
		currentLabel.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
		currentLabel.setForeground(Color.blue);
		currentLabel.setBounds(440, 10, 520, 40);
		add(currentLabel);

		leftTextArea = new JTextArea();
		leftTextArea.setLineWrap(true);
		leftTextArea.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
		leftScrollPane = new JScrollPane(leftTextArea);
		leftScrollPane.setBounds(50, 60, 500, 360);
		leftTextArea.setEditable(false);
		add(leftScrollPane);

		rightTextArea = new JTextArea();
		rightTextArea.setLineWrap(true);
		rightTextArea.setEditable(false);
		rightTextArea.setFont(new Font("Comic Sans MS", Font.BOLD, 20));
		rightScrollPane = new JScrollPane(rightTextArea);
		rightScrollPane.setBounds(610, 60, 510, 360);
		add(rightScrollPane);
	}

	public void CurrentProcess(String string) {
		currentLabel.setText(string);
		if (string.equals("Finish process scheduling !")) {
			
			//在rightTextArea输出结束信息
			rightTextArea.append(">>>>>>----Finish process scheduling----<<<<<<"+'\n');
		}
	}

	public void showProcessInfo() {
		StringBuffer stringBuffer = new StringBuffer();
		int j = 0;
		for (int index = 0; index < 50; index++) {
			LinkedList<PCB> myList = new LinkedList<PCB>();
			myList = ButtonPanel.getLinkedList(index);

			if (myList != null) {
				for (int i = 0; i < myList.size(); i++) {
					PCB aPcb = myList.get(i);
					String statuString;
					if (aPcb.getStatus() == 0) {
						statuString = "Ready";
					} else {
						statuString = "Run";
					}
					stringBuffer.append("Process" + j++ + ":" + "pid:"
							+ aPcb.getPid() + " priority:" + aPcb.getPriority()
							+ " life:" + aPcb.getLife() + " status:"
							+ statuString + "\n");
				}
			}
		}
		leftTextArea.setText(stringBuffer.toString());
	}

	public void showFinishInfo(StringBuffer stringBuffer) {
		rightTextArea.setText("");
		rightTextArea.append(stringBuffer.toString());
	}
	
	public static void addProcessShow(PCB aPcb) {
		String string = "Process" + ":" + "pid:"
				+ aPcb.getPid() + " priority:" + aPcb.getPriority()
				+ " life:" + aPcb.getLife() + " status:"
				+ "Ready" + "\n";
		leftTextArea.append(string);
	}

	private JScrollPane leftScrollPane;
	private JScrollPane rightScrollPane;
	private static JTextArea leftTextArea;
	private JTextArea rightTextArea;

	private static JLabel currentLabel;
}
