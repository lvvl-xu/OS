import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Random;
import java.util.Vector;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

public class ButtonPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ButtonPanel(final ProcessPanel processPanel) {

		pidArray = new int[100];
		for (int i = 0; i < pidArray.length; i++) {
			pidArray[i] = 0;// 表示该进程号空闲
		}

		// 创建50个就绪队列，这里是用链表，功能是一样的
		myQueueVector = new Vector<LinkedList<PCB>>();
		for (int i = 0; i < 50; i++) {
			LinkedList<PCB> pcbLinkedList = new LinkedList<PCB>();
			myQueueVector.add(pcbLinkedList);
		}
		
		//进程过程
		processsStringBuffer = new StringBuffer(" >>>>>>----The scheduling process----<<<<<<"+'\n');
		
		Border etched = BorderFactory.createEtchedBorder();
		Border titleBorder = BorderFactory.createTitledBorder(etched,
				"Options", TitledBorder.LEFT, (int) LEFT_ALIGNMENT, new Font(
						"Comic Sans MS", Font.BOLD, 15));
		setBorder(titleBorder);

		setBounds(10, 10, 1170, 75);
		setBackground(Color.yellow);
		setLayout(new FlowLayout(FlowLayout.CENTER, 20, 5));

		JLabel label = new JLabel("初始随机新建进程个数：");
		add(label);

		numField = new JTextField(10);
		add(numField);

		JButton creatButton = new JButton("创建初始进程");
		creatButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				number = Integer.valueOf(numField.getText()); // 获取到初始要创建的进程数
				for (int i = 0; i < number; i++) {
					creatProcessToQueue(0);
				}
				processPanel.showProcessInfo();
			}
		});
		add(creatButton);

		JButton startButton = new JButton("进行进程调度");
		startButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

				doProcessManager(processPanel);
			}
		});
		add(startButton);

		//暂停调度进程
		JButton stopButton = new JButton("暂停进程调度");
		stopButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				processThread.suspend();
			}
		});
		add(stopButton);
		
		// 动态创建一个进程
		JButton newButton = new JButton("新建一个进程");
		newButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				creatProcessToQueue(1);
			}
		});
		add(newButton);
		
		//恢复进程调度
		JButton resumeButton = new JButton("恢复进程调度");
		resumeButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
//				processThread.resume();
				doProcessManager(processPanel);
			}
		});
		add(resumeButton);
		
		JButton exitButton = new JButton("退出进程调度");
		exitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
		add(exitButton);
	}

	// 进程调度
	void doProcessManager(final ProcessPanel processPanel) {

		processThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				for (int i = 49; i >= 0; i--) {

					LinkedList<PCB> temLinkedList = myQueueVector.get(i);

					while (temLinkedList.size() != 0) {

						for (int j = 0; j < temLinkedList.size(); j++) {

							PCB temPcb = temLinkedList.get(j);
							temPcb.setStatus(1);// Run
							temPcb.setLife((temPcb.getLife() - 1)); // life-1
							temPcb.setPriority(temPcb.getPriority() / 2); // Priority/2

							String currentString = "pid:" + temPcb.getPid()
									+ " priority:" + temPcb.getPriority() + " life:"
									+ temPcb.getLife() + " status:" + "Run";

							processPanel.CurrentProcess(currentString);

							myQueueVector.get(i).remove(j); // remove

							if (temPcb.getLife() > 0) {
								myQueueVector.get(temPcb.getPriority()).add(temPcb);
							}
							//life=0;End
							else if(temPcb.getLife() == 0){
								temPcb.setStatus(2);//End
							}
							
							String statuString = "";
							if (temPcb.getStatus() == 0) {
								statuString = "Ready";
							} else if (temPcb.getStatus() == 1) {
								statuString = "Run";
							}
							else if (temPcb.getStatus() == 2) {
								statuString = "End";
							}
							
							processsStringBuffer.append("Processing-->" + "pid:"
									+ temPcb.getPid() + " priority:" + temPcb.getPriority()
									+ " life:" + temPcb.getLife() + " status:"
									+ statuString + "\n");
							
							processPanel.showFinishInfo(processsStringBuffer);
							//delay
							try {
								Thread.sleep(1000);
							} catch (InterruptedException ex) {
								ex.printStackTrace();
							}
						}
					}
				}
				processPanel.CurrentProcess("Finish process scheduling !");
			}
		});
		processThread.start();
	}

	// 动态创建进程  index == 1 表示是调度过程中的新建
	void creatProcessToQueue(int index) {
		PCB newPCB;
		int aPid;
		do {
			Random aRandom = new Random();
			aPid = aRandom.nextInt(100) % 100;

		} while (pidArray[aPid] != 0);
		pidArray[aPid] = 1; // 表示myPCDPid进程以及分配给某个进程

		// 进程优先级priority 是0 到49范围内的一个随机整数。
		Random bRandom = new Random();
		int aPriority = bRandom.nextInt(50) % 50;
		// 进程生命周期life 是1 到5 范围内的一个随机整数。
		Random cRandom = new Random();
		int aLife = cRandom.nextInt(5) % 5 + 1;

		newPCB = new PCB();

		newPCB.setPid(aPid);
		newPCB.setPriority(aPriority);
		newPCB.setStatus(0);
		newPCB.setLife(aLife);

//		return myQueueVector.get(aPriority).add(newPCB);
		
		myQueueVector.get(aPriority).add(newPCB);
		
		if (index == 1) {
			ProcessPanel.addProcessShow(newPCB);
		}
	}

	private JTextField numField;
	private int number;

	/*
	 * 创建一个下标为1 到100 的布尔数组，“0”表示下标对应的进程标识号是空闲的， “1”表示下标对应的进程标识号已分配给某个进程。
	 */
	private int[] pidArray;

	// 50个就绪队列
	public static Vector<LinkedList<PCB>> myQueueVector;
	
	public static StringBuffer processsStringBuffer;
	
	//调度进程
	private Thread processThread;
	
	public static LinkedList<PCB> getLinkedList(int index) {
		return myQueueVector.get(index);
	}
}
