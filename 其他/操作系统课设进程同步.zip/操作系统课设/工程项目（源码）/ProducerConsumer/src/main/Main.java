package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JOptionPane;

import frame.MyFrame;

public class Main implements ActionListener{

	static MyFrame myFrame;
	static ProducerConsumer producerConsumer;
	public static void main(String[] args) {
		myFrame=new MyFrame();
		new ProducerConsumer();
	}

	
	/* (non-Javadoc)
	* Title: actionPerformed
	* Description: 监听事件，点击按钮时做出相应反应
	* @param e
	* @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	*/ 
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==MyFrame.startButton) {
			//点击开始按钮
			//将显示框清空
			MyFrame.textArea.setText("");
			util.clear();
			String numbers=(String) MyFrame.jcb.getSelectedItem();
			producerConsumer=new ProducerConsumer();
			producerConsumer.setMAX(Integer.valueOf(numbers));
			producerConsumer.run();
			
		}
		
		if(e.getSource()==MyFrame.helpButton) {
			//点击按钮
			File file=new File("./source/help.text");
			try {
				new MyHelp().showHelpWin(file);
			} catch (Exception e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(myFrame, "无法打开帮助文档，请联系 841733321@qq.com", 
					"帮助", JOptionPane.PLAIN_MESSAGE);
			}
			
		}
		
	}

}
