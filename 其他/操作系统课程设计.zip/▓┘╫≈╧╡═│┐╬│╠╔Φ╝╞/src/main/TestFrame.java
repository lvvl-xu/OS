package main;
import java.awt.*;
import java.awt.event.*;
import cpu.CPU;
import course.*;
import memory.*;
import file.*;
import equipment.*;
import javax.swing.*;
public class TestFrame extends JFrame{
	private FileGraphicsUserIndex fileIndex;
	private MemoryPanel memory;
	private CPU cpu;
	private CourseAttemper course;
	private EquipmentManagePanel equipment;
	private static final long serialVersionUID = -1800992918593037579L;
	public TestFrame(){
		JMenuBar menuBar=new JMenuBar();
		this.setJMenuBar(menuBar);
		JMenu file=new JMenu("File");
		JMenuItem exit=new JMenuItem("Exit");
		exit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event){
				System.exit(0);
			}
		});
		file.add(exit);
		menuBar.add(file);
		JMenu help=new JMenu("Help");
		menuBar.add(help);
		JMenu group=new JMenu("Group");
		String[] member=new String[]{"������","���޾�","����","����","������"};
		for(int i=0;i<5;i++){
			group.add(new JMenuItem(member[i]));
		}
		menuBar.add(group);
		//�ļ�����
		JPanel nPanel=new JPanel();
		add(nPanel,BorderLayout.NORTH);
		nPanel.add(fileIndex=new FileGraphicsUserIndex(),BorderLayout.NORTH);
		fileIndex.setPreferredSize(new Dimension(500,260));
		nPanel.add(cpu=new CPU());
		cpu.setPreferredSize(new Dimension(300,260));
		//�ڴ����
		add(memory=new MemoryPanel(),BorderLayout.CENTER);
		memory.setPreferredSize(new Dimension(250,300));
	    //���̹���
		add(course=new CourseAttemper(),BorderLayout.WEST);
		course.setPreferredSize(new Dimension(350,300));
		//�豸����
		add(equipment=new EquipmentManagePanel(),BorderLayout.EAST);
		equipment.setPreferredSize(new Dimension(150,300));
		setBounds(50,50,820,540);
		setTitle("����ϵͳ�γ���ƿ���С�� ָ����ʦ:�׸���");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) throws CreateCourseFailedException{
		JFrame frame=new TestFrame();
		String plaf="com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
		try{
			UIManager.setLookAndFeel(plaf);
			SwingUtilities.updateComponentTreeUI(frame);
		}catch(Exception e){
			JOptionPane.showMessageDialog(null, e);
		}
		frame.setVisible(true);
		CourseAttemper.choseExecuteCourse();
	}
}
