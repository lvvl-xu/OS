package cpu.clock;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;
public class SystemClock extends JPanel{
	private static final long serialVersionUID = 7367687021576665231L;
	private double minutes=0,hours=0,seconds=0;
	private int radius=40;
	private double second_hand_length=0.8*radius;
	private double minute_hand_length=0.7*radius;
	private double hour_hand_length=0.5*radius;
	public SystemClock(){
		setPreferredSize(new Dimension(2*radius+1,2*radius+1));
	}
	public void paintComponent(Graphics g){
		//setBackground(new Color(0x6699ff));
		super.paintComponent(g);
		//draw the circle boundary
		Graphics2D g2=(Graphics2D)g;
		//Ellipse2D circle=new Ellipse2D.Double(0,0,2*radius,2*radius);
		g2.setColor(new Color(0x669922));
	//	g2.draw(circle);
        //draw number
		g2.drawString("9", 2, radius+5);
		g2.drawString("10", 5, radius-12);
		g2.drawString("11", 20, radius-27);
		g2.drawString("12",radius-5,12);
		g2.drawString("1",radius+15,radius-25);
		g2.drawString("2",radius+25,radius-15);
		g2.drawString("3",radius*2-9,radius+5);
		g2.drawString("4", 2*radius-15, radius+25);
		g2.drawString("5", 2*radius-30, radius+37);
		g2.drawString("6",radius-5,2*radius);
		g2.drawString("7", radius-24, 2*radius-6);
		g2.drawString("8", radius-35, 2*radius-20);
		//draw the hour hand
		g2.setColor(Color.black);
		double hourAngle=Math.toRadians(90-(30*hours+minutes/2));
		drawHand(g2,hourAngle,hour_hand_length);
		//draw the minutes hand
		g2.setColor(new Color(0x6699ff));
		double minuteAngle=Math.toRadians(90-360*minutes/60);
		drawHand(g2,minuteAngle,minute_hand_length);
		//draw the secomnds hand
		double secondAngle=Math.toRadians(90-360*seconds/60);
		g2.setColor(Color.red);
		drawHand(g2,secondAngle,second_hand_length);
	}
	public void drawHand(Graphics2D g2,double angle,double handLength){
		Point2D end=new Point2D.Double(
				radius+handLength*Math.cos(angle),
				radius-handLength*Math.sin(angle));
		Point2D center=new Point2D.Double(radius,radius);
		g2.draw(new Line2D.Double(center,end));
	}
	public void setTime(int h,int m,int s){
		hours=h;
		minutes=m;
		seconds=s;
		repaint();
	}
	public static void main(String[] args){
		JFrame frame=new JFrame();
		frame.setBounds(new Rectangle(100,100,300,200));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new SystemClock());
		frame.setVisible(true);
	}
}
