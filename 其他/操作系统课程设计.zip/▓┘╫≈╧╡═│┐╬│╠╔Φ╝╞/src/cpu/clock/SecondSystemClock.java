package cpu.clock;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.*;
public class SecondSystemClock extends JPanel{
	private static final long serialVersionUID = 8575699985025182437L;
	private SystemClock clock=new SystemClock();
	private int hour,minute,second;
	private Timer timer;
	public SecondSystemClock(){
		setLayout(new BorderLayout());
		setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createEtchedBorder(),"ϵͳʱ��"));
		//ʱ�����
		JPanel clockPanel=new JPanel();
		JPanel nullPanel=new JPanel();
		nullPanel.setPreferredSize(new Dimension(1,1));
		clockPanel.add(nullPanel);
		clockPanel.add(clock);
		add(clockPanel,BorderLayout.NORTH);
		JTextArea txt=new JTextArea(5,1);
		txt.setEditable(false);
		txt.setForeground(Color.green);
		txt.setBackground(new Color(0xffffff));
		txt.setText("\n����С���Ա��\n������ ���޾� ���� ���� ������\n�鳤��������");
		add(txt,BorderLayout.CENTER);
		GregorianCalendar calendar=new GregorianCalendar();
		hour=calendar.get(Calendar.HOUR);
		minute=calendar.get(Calendar.MINUTE);
		second=calendar.get(Calendar.SECOND);
		timer=new Timer(1000,new ActionListener(){
			public void actionPerformed(ActionEvent event){
				second+=1;
				if(second==60){
					second=0;
					minute+=1;
					if(minute==60){
						minute=0;
						hour+=1;
						if(hour==24)
							hour=0;
					}
				}
				clock.setTime(hour,minute,second);
			}
		});
		timer.start();
	}
	public static void main(String[] args){
		JFrame frame=new JFrame();
		frame.setBounds(new Rectangle(100,100,300,200));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new SecondSystemClock());
		frame.setVisible(true);
	}
}
