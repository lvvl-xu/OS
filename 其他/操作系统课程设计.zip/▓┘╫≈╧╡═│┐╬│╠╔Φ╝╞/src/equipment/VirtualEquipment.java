package equipment;
public class VirtualEquipment {
	private char equipmentName;
	private boolean freeFlag;
	private int workTime;
	public VirtualEquipment(char name){
		equipmentName=name;
		freeFlag=false;//�豸����
	}
	public char getEquipmentName(){
		return equipmentName;
	}
	public boolean isFree(){
		return !freeFlag;
	}
	public void setFree(){
		freeFlag=false;
	}
	public void applyEquipment(int time)throws EquipmentBusyException{
		if(!isFree())
			throw new EquipmentBusyException();
		freeFlag=true;
		workTime=time;
	}
	public void timeDecrease()throws EquipmentHasBeenFree{
		workTime--;
		if(workTime==0){
			freeFlag=false;
			throw new EquipmentHasBeenFree();
		}
	}
	public class EquipmentHasBeenFree extends Exception{
		private static final long serialVersionUID = 1L;
		public EquipmentHasBeenFree(){}
		public String toString(){
			return "�豸�Ѿ�����";
		}
	}
	public class EquipmentBusyException extends Exception{
		private static final long serialVersionUID = 1L;
		public EquipmentBusyException(){};
		public String toString(){
			return "�豸��æ!";
		}
	}
}
