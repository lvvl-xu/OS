package equipment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class EquipmentManagePanel extends JPanel{
	private static final long serialVersionUID = 1L;
	private static VirtualEquipment A1,B1,B2,C1,C2,C3;
	private static JRadioButton a1Radio,b1Radio,b2Radio,c1Radio,c2Radio,c3Radio;
	private JPanel nPanel,cPanel,sPanel;
	private static Timer[] equipmentTimer=new Timer[6];
	private static Timer[] clockTimer=new Timer[6];
	private static JTextField[] field=new JTextField[6];
	public EquipmentManagePanel(){
		setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createEtchedBorder(),"�豸����(������)"));
		setLayout(new BorderLayout());
		A1=new VirtualEquipment('A');
		B1=new VirtualEquipment('B');
		B2=new VirtualEquipment('B');
		C1=new VirtualEquipment('C');
		C2=new VirtualEquipment('C');
		C3=new VirtualEquipment('C');
		add(nPanel=new JPanel(),BorderLayout.NORTH);
		add(cPanel=new JPanel(),BorderLayout.CENTER);
		addLabelAndRadio(new JLabel("A1"),a1Radio=new JRadioButton(),1);
		addLabelAndRadio(new JLabel("B1"),b1Radio=new JRadioButton(),1);
		addLabelAndRadio(new JLabel("B2"),b2Radio=new JRadioButton(),1);
		addLabelAndRadio(new JLabel("C1"),c1Radio=new JRadioButton(),2);
		addLabelAndRadio(new JLabel("C2"),c2Radio=new JRadioButton(),2);
		addLabelAndRadio(new JLabel("C3"),c3Radio=new JRadioButton(),2);
		add(sPanel=new JPanel(),BorderLayout.SOUTH);
		sPanel.setLayout(new GridLayout(6,2));
		String[] labelName=new String[]{"A1ʣ��ʱ��","B1ʣ��ʱ��","B2ʣ��ʱ��",
				"C1ʣ��ʱ��","C2ʣ��ʱ��","C3ʣ��ʱ��"};
		for(int i=0;i<6;i++){
			JLabel label=new JLabel(labelName[i]);
			label.setEnabled(false);
			sPanel.add(label);
			sPanel.add(field[i]=new JTextField(2));
			field[i].setEditable(false);
		}
	}
	public static void applyEquipment(char name,int time)throws VirtualEquipment.EquipmentBusyException{
		time=time-48;
		if(name=='A'){
			if(A1.isFree()){
				A1.applyEquipment(time);
				a1Radio.setSelected(true);
				setTimerState(A1,time,a1Radio,0);
			}
			else throw A1.new EquipmentBusyException();
		}else if(name=='B'){
			if(B1.isFree()){
				B1.applyEquipment(time);
				b1Radio.setSelected(true);
				setTimerState(B1,time,b1Radio,1);
			}
			else if(B2.isFree()){
				B2.applyEquipment(time);
				b2Radio.setSelected(true);
				setTimerState(B2,time,b2Radio,2);
			}
			else throw B1.new EquipmentBusyException();
		}else if(name=='C'){
			if(C1.isFree()){
				C1.applyEquipment(time);
				c1Radio.setSelected(true);
				setTimerState(C1,time,c1Radio,3);
			}
			else if(C2.isFree()){
				C2.applyEquipment(time);
				c2Radio.setSelected(true);
				setTimerState(C2,time,c2Radio,4);
			}
			else if(C3.isFree()){
				C3.applyEquipment(time);
				c3Radio.setSelected(true);
				setTimerState(C2,time,c3Radio,5);
			}
			else throw B1.new EquipmentBusyException();
		}
	}
	private static void setTimerState(final VirtualEquipment equipment,int timesize,
			final JRadioButton radio,final int index){
		field[index].setText(String.valueOf(timesize));
		equipmentTimer[index]=new Timer(1000*timesize,new ActionListener(){
			public void actionPerformed(ActionEvent event){
				radio.setSelected(false);
				equipment.setFree();
				field[index].setText("");
				equipmentTimer[index].stop();
				clockTimer[index].stop();
			}
		});
		clockTimer[index]=new Timer(1000,new ActionListener(){
			public void actionPerformed(ActionEvent event){
				if(field[index].getText().equals(""))return;
				field[index].setText(
						String.valueOf(Integer.parseInt(field[index].getText())-1));
			}
		});
		equipmentTimer[index].start();
		clockTimer[index].start();
	}
	public void addLabelAndRadio(JLabel label,JRadioButton button,int n){
		if(n==1){
			nPanel.add(label);
			nPanel.add(button);
		}else{
			cPanel.add(label);
			cPanel.add(button);
		}
		button.setEnabled(false);
	}
}
