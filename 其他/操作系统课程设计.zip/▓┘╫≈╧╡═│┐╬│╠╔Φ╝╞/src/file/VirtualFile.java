package file;
public class VirtualFile {
	private byte[] control=new byte[8];
	private String content=new String();
	public static final char EXTENSION_CHAR_FILE='c';//�ַ��ļ�
	public static final char EXTENSION_EXECUTE_FILE='e';//��ִ���ļ�
	public static final char EXETENSION_DIRECTORY_FILE='d';//Ŀ¼�ļ�
	/**
	 * @param fileName �ļ���
	 * @param extension ��չ��
	 */
	public VirtualFile(String fileName,char extension){
		setFileName(fileName);
		control[3]=(byte)extension;
	}
	public VirtualFile(String fileName,char extension,String content){
		setFileName(fileName);
		control[3]=(byte)extension;
		this.content=content;
	}
	//�����ļ���ʼ���̿�
	public void setStartBlockNum(int start){ control[5]=(byte)start;}
	public void setFileLength(int length){
		control[6]=(byte)(length/128);
		control[7]=(byte)(length%128);
	}
	//�����ļ���
	public void setFileName(String fileName){
		for(int i=0;i<fileName.length()&&i<3;i++)
			control[i]=(byte)fileName.charAt(i);
	}
	//�����ļ�����
	public String getFileContent(){return content;}
	//�����ļ�����
	public byte[] getFileControl(){return control;}
	public void setContent(String newContent){
		content=newContent;
	}
	public String getFileName(){
		String result=new String();
		char[] name=new char[3];
		for(int i=0;i<3;i++)
			name[i]=(char)control[i];
		result=String.valueOf(name);
		return result;
	}
	public String getFileExtension(){
		return String.valueOf((char)control[3]);
	}
	public String toString(){
		String result="";
		for(int i=0;i<3;i++)
			result+=String.valueOf((char)control[i]);
		if(control[3]==(byte)EXETENSION_DIRECTORY_FILE)return result;
		result+=".";
		result+=String.valueOf((char)control[3]);
		return result;
	}
}
